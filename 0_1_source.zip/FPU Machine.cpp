/**************************************************************************
 *                                                                        *
 *               Copyright (C) 2000, Eclipse Productions                  *
 *                                                                        *
 *  Offical Source code of the Apollo Project.  DO NOT DISTRIBUTE!  Any   *
 *  unauthorized distribution of these files in any way, shape, or form   *
 *  is a direct infringement on the copyrights entitled to Eclipse        *
 *  Productions and will you will be prosecuted to the fullest extent of  *
 *  the law.  Have a nice day... ^_^                                      *
 *                                                                        *
 *************************************************************************/

/**************************************************************************
 *
 *  Revision History:
 *		Date:		Comment:
 *	-----------------------------------------------------------------------
 *		03-29-00	Initial Version (Andrew)
 *
 **************************************************************************/

/**************************************************************************
 *
 *  Notes:
 *	
 *	Sections of the FPU not correctly emulated:
 *	-All sections of the FC[31] except the rounding mode - And not initially filled.
 *  -FC[0] not filled with any data--should be revision register
 *  -The conversion process is not correctly done when the destination is an integer.
 *  -The conditional opcodes for integer will currently fail with as a NI (not implemented)
 *  
 *  
 *
 **************************************************************************/
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include "WindowsMain.h"
#include "EmuMain.h"
#include "resource.h"

#define CPU_ERROR(x,y) Log(9,"%s %08X",x,y)

void doInstr();

#define START_TRUNICATE_FPU() \
	u32 RCold = _control87(_RC_CHOP, _MCW_RC);
#define END_TRUNICATE_FPU() \
	_control87(RCold, _MCW_RC);
#define START_FLOOR_FPU() \
	u32 RCold = _control87(_RC_DOWN, _MCW_RC);
#define END_FLOOR_FPU() \
	_control87(RCold, _MCW_RC);
#define START_CEILING_FPU() \
	u32 RCold = _control87(_RC_UP, _MCW_RC);
#define END_CEILING_FPU() \
	_control87(RCold, _MCW_RC);
#define START_ROUND_FPU() \
	u32 RCold = _control87(_RC_NEAR, _MCW_RC);
#define END_ROUND_FPU() \
	_control87(RCold, _MCW_RC);

#define FC_UNSET() \
	FpuControl[31] &= ~(0x00800000);

#define FC_SET(x) \
	if ((x)) FpuControl[31] |= 0x00800000;

void opNI();

extern void (*FpuCommands16[0x40])();
extern void (*FpuCommands17[0x40])();
extern void (*FpuCommands20[0x40])();
extern void (*FpuCommands21[0x40])();

extern DWORD opcode;
extern R4K_FPU_union FpuRegs;

int frt;
int frd;
int fsa;

void opCOP1(void) {
	((DWORD*)&sop)[0] = opcode;
	frd = sop.rd;
	frt = sop.rt;
	fsa = sop.sa;
	switch (sop.rs) {
	case 0:
		CpuRegs[frt] = (s32)FpuRegs.w[frd];
		break;
	case 1:
		CpuRegs[frt] = FpuRegs.l[frd/2];
		break;
	case 2:
		CpuRegs[frt] = (s32)FpuControl[frd];
		break;
	case 4:
		FpuRegs.w[frd] = (s32)CpuRegs[frt];
		break;
	case 5:
		FpuRegs.l[frd/2] = CpuRegs[frt];
		break;
	case 6:
		FpuControl[frd] = (u32)CpuRegs[frt];
		switch (FpuControl[31] & 3) {
		case 0:
			_control87(_RC_NEAR, _MCW_RC);
			break;
		case 1:
			_control87(_RC_CHOP, _MCW_RC);
			break;
		case 2:
			_control87(_RC_UP, _MCW_RC);
			break;
		default:
			_control87(_RC_DOWN, _MCW_RC);
			break;
		}
		break;
	case 8:
		switch (frt & 3){
		case 0x0://BC1F
			if (!(FpuControl[31] & 0x00800000)) {
				u32 target = pc + ((s16(opcode)) << 2);
				doInstr();
				pc = target;
			}
			break;
		case 0x1://BC1T
			if (FpuControl[31] & 0x00800000) {
				u32 target = pc + ((s16(opcode)) << 2);
				doInstr();
				pc = target;
			}
			break;
		case 0x2://BC1FL
			if (!(FpuControl[31] & 0x00800000)) {
				u32 target = pc + ((s16(opcode)) << 2);
				doInstr();
				pc = target;
			} else pc += 4;
			break;
		case 0x3://BC1TL
			if (FpuControl[31] & 0x00800000) {
				u32 target = pc + ((s16(opcode)) << 2);
				doInstr();
				pc = target;
			} else pc += 4;
		default:
			break;
		}			
		break;
	case 16:
		FpuCommands16[sop.func]();
		break;
	case 17:
		FpuCommands17[sop.func]();
		break;
	case 20:
		FpuCommands20[sop.func]();
		break;
	case 21:
		FpuCommands21[sop.func]();
		break;
	default:
		CPU_ERROR("cop1 (fpu)",opcode);
		break;
	}
}

void fpADD16(void){
	FpuRegs.s[fsa] = FpuRegs.s[frd] + FpuRegs.s[frt];
}

void fpADD17(void){
	FpuRegs.d[fsa/2] = FpuRegs.d[frd/2] + FpuRegs.d[frt/2];
}

void fpADD20(void){
	FpuRegs.w[fsa] = FpuRegs.w[frd] + FpuRegs.w[frt];
}

void fpADD21(void){
	FpuRegs.l[fsa/2] = FpuRegs.l[frd/2] + FpuRegs.l[frt/2];
}

void fpSUB16(void){
	FpuRegs.s[fsa] = FpuRegs.s[frd] - FpuRegs.s[frt];
}

void fpSUB17(void){
	FpuRegs.d[fsa/2] = FpuRegs.d[frd/2] - FpuRegs.d[frt/2];
}

void fpSUB20(void){
	FpuRegs.w[fsa] = FpuRegs.w[frd] - FpuRegs.w[frt];
}

void fpSUB21(void){
	FpuRegs.l[fsa/2] = FpuRegs.l[frd/2] - FpuRegs.l[frt/2];
}

void fpMUL16(void){
	FpuRegs.s[fsa] = FpuRegs.s[frd] * FpuRegs.s[frt];
}

void fpMUL17(void){
	FpuRegs.d[fsa/2] = FpuRegs.d[frd/2] * FpuRegs.d[frt/2];
}

void fpMUL20(void){
	FpuRegs.w[fsa] = FpuRegs.w[frd] * FpuRegs.w[frt];
}

void fpMUL21(void){
	FpuRegs.l[fsa/2] = FpuRegs.l[frd/2] * FpuRegs.l[frt/2];
}

void fpDIV16(void){
	if (FpuRegs.s[frt]==0) FpuRegs.s[fsa] = 0;
	else FpuRegs.s[fsa] = FpuRegs.s[frd] / FpuRegs.s[frt];
}

void fpDIV17(void){
	if (FpuRegs.d[frt/2]==0) FpuRegs.d[fsa/2] = 0;
	else FpuRegs.d[fsa/2] = FpuRegs.d[frd/2] / FpuRegs.d[frt/2];
}

void fpDIV20(void){
	if (FpuRegs.w[frt]==0) FpuRegs.w[fsa] = 0;
	else FpuRegs.w[fsa] = FpuRegs.w[frd] / FpuRegs.w[frt];
}

void fpDIV21(void){
	if (FpuRegs.l[frt/2]==0) FpuRegs.l[fsa/2] = 0;
	else FpuRegs.l[fsa/2] = FpuRegs.l[frd/2] / FpuRegs.l[frt/2];
}

void fpSRT16(void){
	FpuRegs.s[fsa] = (float)sqrt(FpuRegs.s[frd]);
}

void fpSRT17(void){
	FpuRegs.d[fsa/2] = sqrt(FpuRegs.d[frd/2]);
}

void fpSRT20(void){
	FpuRegs.w[fsa] = (long)sqrt(FpuRegs.w[frd]);
}

void fpSRT21(void){
	FpuRegs.l[fsa/2] = (s64)sqrt((double)FpuRegs.l[frd/2]);
}

void fpABS16(void){
	FpuRegs.s[fsa] = (float)fabs(FpuRegs.s[frd]);
}

void fpABS17(void){
	FpuRegs.d[fsa/2] = fabs(FpuRegs.d[frd/2]);
}

void fpABS20(void){
	FpuRegs.w[fsa] = (s32)fabs(FpuRegs.w[frd]);
}

void fpABS21(void){
	FpuRegs.l[fsa/2] = (s64)fabs((double)FpuRegs.l[frd/2]);
}

void fpMOV16(void){
	FpuRegs.s[fsa] = FpuRegs.s[frd];
}

void fpMOV17(void){
	FpuRegs.d[fsa/2] = FpuRegs.d[frd/2];
}

void fpNEG16(void){
	FpuRegs.s[fsa] = -FpuRegs.s[frd];
}

void fpNEG17(void){
	FpuRegs.d[fsa/2] = -FpuRegs.d[frd/2];
}

void fpNEG20(void){
	FpuRegs.w[fsa] = -FpuRegs.w[frd];
}

void fpNEG21(void){
	FpuRegs.l[fsa/2] = -FpuRegs.l[frd/2];
}

void fpTRCl16(void){
	START_TRUNICATE_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.s[frd];
	END_TRUNICATE_FPU();
}

void fpTRCl17(void){
	START_TRUNICATE_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.d[frd/2];
	END_TRUNICATE_FPU();
}

void fpCELl16(void){
	START_CEILING_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.s[frd];
	END_CEILING_FPU();
}

void fpCELl17(void){
	START_CEILING_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.d[frd/2];
	END_CEILING_FPU();
}

void fpRNDw16(void){
	START_ROUND_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.s[frd];
	END_ROUND_FPU();
}

void fpRNDw17(void){
	START_ROUND_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.d[frd/2];
	END_ROUND_FPU();
}

void fpRNDl16(void){
	START_ROUND_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.s[frd];
	END_ROUND_FPU();
}

void fpRNDl17(void){
	START_ROUND_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.d[frd/2];
	END_ROUND_FPU();
}


void fpFLRw16(void){
	START_FLOOR_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.s[frd];
	END_FLOOR_FPU();
}

void fpFLRw17(void){
	START_FLOOR_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.d[frd/2];
	END_FLOOR_FPU();
}

void fpFLRl16(void){
	START_FLOOR_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.s[frd];
	END_FLOOR_FPU();
}

void fpFLRl17(void){
	START_FLOOR_FPU();
	FpuRegs.l[fsa/2] = (s64)FpuRegs.d[frd/2];
	END_FLOOR_FPU();
}

void fpTRCw16(void){
	START_TRUNICATE_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.s[frd];
	END_TRUNICATE_FPU();
}

void fpTRCw17(void){
	START_TRUNICATE_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.d[frd/2];
	END_TRUNICATE_FPU();
}

void fpCELw16(void){
	START_CEILING_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.s[frd];
	END_CEILING_FPU();
}

void fpCELw17(void){
	START_CEILING_FPU();
	FpuRegs.w[fsa] = (s32)FpuRegs.d[frd/2];
	END_CEILING_FPU();
}

void fpCVTs17(void){
	FpuRegs.s[fsa] = (float)FpuRegs.d[frd/2];
}

void fpCVTs20(void){
	FpuRegs.s[fsa] = (float)FpuRegs.w[frd];
}

void fpCVTs21(void){
	FpuRegs.s[fsa] = (float)FpuRegs.d[frd/2];
}

void fpCVTd16(void){
	FpuRegs.d[fsa/2] = FpuRegs.s[frd];
}

void fpCVTd20(void){
	FpuRegs.d[fsa/2] = FpuRegs.w[frd];
}

void fpCVTd21(void){
	FpuRegs.d[fsa/2] = FpuRegs.d[frd/2];
}

void fpCVTw16(void){
	FpuRegs.w[fsa] = (s32)FpuRegs.s[frd];
}

void fpCVTw17(void){
	FpuRegs.w[fsa] = (s32)FpuRegs.d[frd/2];
}

void fpCVTl16(void){
	FpuRegs.l[fsa/2] = (s64)FpuRegs.s[frd];
}

void fpCVTl17(void){
	FpuRegs.l[fsa/2] = (s64)FpuRegs.d[frd/2];
}

void fpC_F16(void){
	//0000
	FC_UNSET();
}

void fpC_F17(void){
	//0000
	FC_UNSET();
}

void fpC_UN16(void){
	//0001
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])); 
}

void fpC_UN17(void){
	//0001
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])); 
}

void fpC_EQ16(void){
	//0010
	FC_UNSET();
	FC_SET(FpuRegs.s[frd]==FpuRegs.s[frt]); 
}

void fpC_EQ17(void){
	//0010
	FC_UNSET();
	FC_SET(FpuRegs.d[frd/2]==FpuRegs.d[frt/2]); 
}

void fpC_UEQ16(void){
	//0011
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])); 
	FC_SET(FpuRegs.s[frd]==FpuRegs.s[frt]); 
}

void fpC_UEQ17(void){
	//0011
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])); 
	FC_SET(FpuRegs.d[frd/2]==FpuRegs.d[frt/2]); 
}

void fpC_OLT16(void){
	//0100
	FC_UNSET();
	FC_SET(FpuRegs.s[frd]<FpuRegs.s[frt]); 
}

void fpC_OLT17(void){
	//0100
	FC_UNSET();
	FC_SET(FpuRegs.d[frd/2]<FpuRegs.d[frt/2]); 
}

void fpC_ULT16(void){
	//0101
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])); 
	FC_SET(FpuRegs.s[frd]<FpuRegs.s[frt]); 
}

void fpC_ULT17(void){
	//0101
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])); 
	FC_SET(FpuRegs.d[frd/2]<FpuRegs.d[frt/2]); 
}

void fpC_OLE16(void){
	//0110
	FC_UNSET();
	FC_SET(FpuRegs.s[frd]<=FpuRegs.s[frt]); 
}

void fpC_OLE17(void){
	//0110
	FC_UNSET();
	FC_SET(FpuRegs.d[frd/2]<=FpuRegs.d[frt/2]); 
}

void fpC_ULE16(void){
	//0111
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])); 
	FC_SET(FpuRegs.s[frd]<=FpuRegs.s[frt]); 
}

void fpC_ULE17(void){
	//0111
	FC_UNSET();
	FC_SET(_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])); 
	FC_SET(FpuRegs.d[frd/2]<=FpuRegs.d[frt/2]); 
}

void fpC_SF16(void){
	//1000
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { CPU_ERROR("NaN found!",opcode); }
}

void fpC_SF17(void){
	//1000
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { CPU_ERROR("NaN found!",opcode); }
}

void fpC_NGLE16(void){
	//1001
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
}

void fpC_NGLE17(void){
	//1001
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
}

void fpC_SEQ16(void){
	//1010
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]==FpuRegs.s[frt]); 
}

void fpC_SEQ17(void){
	//1010
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]==FpuRegs.d[frt/2]); 
}

void fpC_NGL16(void){
	//1011
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]==FpuRegs.s[frt]); 
}

void fpC_NGL17(void){
	//1011
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]==FpuRegs.d[frt/2]); 
}

void fpC_LT16(void){
	//1100
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]<FpuRegs.s[frt]); 
}

void fpC_LT17(void){
	//1100
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]<FpuRegs.d[frt/2]); 
}

void fpC_NGE16(void){
	//1101
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]<FpuRegs.s[frt]); 
}

void fpC_NGE17(void){
	//1101
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]<FpuRegs.d[frt/2]); 
}

void fpC_LE16(void){
	//1110
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]<=FpuRegs.s[frt]); 
}

void fpC_LE17(void){
	//1110
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]<=FpuRegs.d[frt/2]); 
}

void fpC_NGT16(void){
	//1111
	FC_UNSET();
	if (_isnan(FpuRegs.s[frd]) || _isnan(FpuRegs.s[frt])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.s[frd]<=FpuRegs.s[frt]); 
}

void fpC_NGT17(void){
	//1111
	FC_UNSET();
	if (_isnan(FpuRegs.d[frd/2]) || _isnan(FpuRegs.d[frt/2])) { FC_SET(1); CPU_ERROR("NaN found!",opcode); }
	FC_SET(FpuRegs.d[frd/2]<=FpuRegs.d[frt/2]); 
}

void (*FpuCommands16[0x40])() =
{
    fpADD16,	fpSUB16,	fpMUL16,	fpDIV16,	fpSRT16,	fpABS16,	fpMOV16,	fpNEG16,
    fpRNDl16,	fpTRCl16,	fpCELl16,	fpFLRl16,	fpRNDw16,	fpTRCw16,	fpCELw16,	fpFLRw16,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		fpCVTd16,	opNI,		opNI,		fpCVTw16,	fpCVTl16,	opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    fpC_F16,	fpC_UN16,	fpC_EQ16,	fpC_UEQ16,	fpC_OLT16,	fpC_ULT16,	fpC_OLE16,	fpC_ULE16,
    fpC_SF16,	fpC_NGLE16,	fpC_SEQ16,	fpC_NGL16,	fpC_LT16,	fpC_NGE16,	fpC_LE16,	fpC_NGT16
};

void (*FpuCommands17[0x40])() =
{
    fpADD17,	fpSUB17,	fpMUL17,	fpDIV17,	fpSRT17,	fpABS17,	fpMOV17,	fpNEG17,
    fpRNDl17,	fpTRCl17,	fpCELl17,	fpFLRl17,	fpRNDw17,	fpTRCw17,	fpCELw17,	fpFLRw17,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    fpCVTs17,	opNI,		opNI,		opNI,		fpCVTw17,	fpCVTl17,	opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    fpC_F17,	fpC_UN17,	fpC_EQ17,	fpC_UEQ17,	fpC_OLT17,	fpC_ULT17,	fpC_OLE17,	fpC_ULE17,
    fpC_SF17,	fpC_NGLE17,	fpC_SEQ17,	fpC_NGL17,	fpC_LT17,	fpC_NGE17,	fpC_LE17,	fpC_NGT17
};

void (*FpuCommands20[0x40])() =
{
    fpADD20,	fpSUB20,	fpMUL20,	fpDIV20,	fpSRT20,	fpABS20,	opNI,		fpNEG20,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    fpCVTs20,	fpCVTd20,	opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
//    fpC_F20,	fpC_UN20,	fpC_EQ20,	fpC_UEQ20,	fpC_OLT20,	fpC_ULT20,	fpC_OLE20,	fpC_ULE20,
//    fpC_SF20,	fpC_NGLE20,	fpC_SEQ20,	fpC_NGL20,	fpC_LT20,	fpC_NGE20,	fpC_LE20,	fpC_NGT20
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI
};

void (*FpuCommands21[0x40])() =
{
    fpADD21,	fpSUB21,	fpMUL21,	fpDIV21,	fpSRT21,	fpABS21,	opNI,		fpNEG21,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    fpCVTs21,	fpCVTd21,	opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
//    fpC_F21,	fpC_UN21,	fpC_EQ21,	fpC_UEQ21,	fpC_OLT21,	fpC_ULT21,	fpC_OLE21,	fpC_ULE21,
//    fpC_SF21,	fpC_NGLE21,	fpC_SEQ21,	fpC_NGL21,	fpC_LT21,	fpC_NGE21,	fpC_LE21,	fpC_NGT21
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI,		opNI
};