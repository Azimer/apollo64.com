#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <math.h>
#include "WindowsMain.h"
#include "EmuMain.h"
#include "resource.h"
#pragma warning( disable : 4244 )

#define CPU_ERROR(x,y) Log(9,"%s %08X",x,y)

#define FAST_INFINITE_LOOP

extern u32 VsyncTime;
extern u32 VsyncInterrupt;
u64 CpuRegs[32];
u64 MmuRegs[32];
R4K_FPU_union FpuRegs;
u64 FpuControl[32];
u64 cpuHi;
u64 cpuLo;
u32 instructions = 0;
volatile u32 pc;
u32 opcode;
volatile char InterruptNeeded=0;
s_sop sop;
s_tlb tlb[32];

extern void (*r4300i[0x40])();
extern void (*special[0x40])();
extern void (*regimm[0x20])();
extern void (*MmuSpecial[0x40])();
extern void (*MmuNormal[0x20])();
extern void (*FpuCommands[0x40])();

void doInstr(void) {
		((u32*)&sop)[0] = opcode = vr32(pc);
		pc+=4;
		r4300i[sop.op]();
}

void Emulate(void) {
	u32 i;
	extern bool paused;

	for (i=0; i < 32; i++) {
		tlb[i].hh = tlb[i].hl = tlb[i].ll = tlb[i].lh = 0;
		tlb[i].isGlobal = 0;
	}
	pc = 0xA4000040;
	
	MmuRegs[0x0C] = 0x00400004;    // Status
	MmuRegs[0x0F] = 0x00000411;    // PRevID
	MmuRegs[0x10] = 0x00066463;    // Config
	MmuRegs[0x01] = 0x2F;          // Random
	CpuRegs[0x1D] = (s32)0xA4001FF0;    // SP
	CpuRegs[0x16] = 0x3F;          // S6?
	CpuRegs[0x14] = 1;             // S4
	CpuRegs[31]=(s32)0x80000000;
	cpuHi = 0;
	cpuLo = 0;
	instructions = 0;
	VsyncTime = VsyncInterrupt = 625000;

	while (!done) {

		CheckInterrupts();

		((u32*)&sop)[0] = opcode = vr32(pc);
		pc+=4;
		r4300i[sop.op]();
	}
}

void opCOP0(void) {
	if (sop.rs == 16) MmuSpecial[sop.func]();
	else MmuNormal[sop.rs]();
}

void opCOP2(void) {
	CPU_ERROR("COP2 Called",pc);
}

void opNI(void) {
	CPU_ERROR("NI Called",pc);
}

void opSPECIAL ( void ) {
	special[sop.func]();
}

void opREGIMM( void ) {
	regimm[sop.rt]();
}

void opADD(void) {
	CpuRegs[sop.rd] = (s32)(CpuRegs[sop.rt] + CpuRegs[sop.rs]);
}

void opADDI(void) {
	CpuRegs[sop.rt] = (s32)(CpuRegs[sop.rs] + ((s16)opcode));
}

void opADDIU(void) {
	CpuRegs[sop.rt] = (s32)(CpuRegs[sop.rs] + ((s16)opcode));
}

void opADDU(void) {
	CpuRegs[sop.rd] = (s32)(CpuRegs[sop.rt] + CpuRegs[sop.rs]);
}

void opAND(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] & CpuRegs[sop.rs];
}

void opANDI(void) {
	CpuRegs[sop.rt] = CpuRegs[sop.rs] & ((u16)opcode);
}

void opBEQ(void) {
	u32 Jpc = pc;
	if (CpuRegs[sop.rt] == CpuRegs[sop.rs]) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		int brt = sop.rt;
		int brs = sop.rs;
		doInstr();
		pc = target;
#ifdef FAST_INFINITE_LOOP
	if (target==Jpc-4 && pr32(Jpc)==0 && brt==brs) { 
		Jpc = pc;
		do {
			CheckInterrupts();//Kind of a way to speed up emulation.
		} while (Jpc==pc);
	}
#endif
	}
}

void opBEQL(void) {
	if (CpuRegs[sop.rt] == CpuRegs[sop.rs]) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	} else pc +=4;
}

void opBGEZ(void) {
	if (((s64)CpuRegs[sop.rs]) >= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}
}

void opBGEZAL(void) {
	if (((s64)CpuRegs[sop.rs]) >= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		CpuRegs[31] = pc+4;
		doInstr();
		pc = target;
	}
}

void opBGEZALL(void) {
	if (((s64)CpuRegs[sop.rs]) >= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		CpuRegs[31] = pc+4;
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBGEZL(void) {
	if (((s64)CpuRegs[sop.rs]) >= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBGTZ(void) {
	if (((s64)CpuRegs[sop.rs]) > 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}
}

void opBGTZL(void) {
	if (((s64)CpuRegs[sop.rs]) > 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBLEZ(void) {
	if (((s64)CpuRegs[sop.rs]) <= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}
}

void opBLEZL(void) {
	if (((s64)CpuRegs[sop.rs]) <= 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBLTZ(void) {
	if (((s64)CpuRegs[sop.rs]) < 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}
}

void opBLTZAL(void) {
	if (((s64)CpuRegs[sop.rs]) < 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		CpuRegs[31] = pc+4;
		doInstr();
		pc = target;
	}
}

void opBLTZALL(void) {
	if (((s64)CpuRegs[sop.rs]) < 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		CpuRegs[31] = pc+4;
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBLTZL(void) {
	if (((s64)CpuRegs[sop.rs]) < 0) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}else pc+=4;
}

void opBNE(void) {
	if (CpuRegs[sop.rt] != CpuRegs[sop.rs]) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	}
}

void opBNEL(void) {
	if (CpuRegs[sop.rt] != CpuRegs[sop.rs]) {
		u32 target = ((s16)opcode);
		target = pc + (target << 2);
		doInstr();
		pc = target;
	} else pc+=4;
}

void opBREAK(void) {
	Log(0,"BREAK opcode at %X, A2:%X, VO:%X\n",pc,CpuRegs[6],CpuRegs[2]);
	CPU_ERROR("Break Called",pc);
}

void opCACHE(void) { }

void opDADD(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] + CpuRegs[sop.rs];
}

void opDADDI(void) {
	CpuRegs[sop.rt] = CpuRegs[sop.rs] + ((s16)opcode);
}

void opDADDIU(void) {
	CpuRegs[sop.rt] = CpuRegs[sop.rs] + ((s16)opcode);
}

void opDADDU(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] + CpuRegs[sop.rs];
}

void opDDIV(void) {
	if (CpuRegs[sop.rt] == 0) {
		cpuLo = cpuHi = 0;
	} else {
		cpuLo = (s64)CpuRegs[sop.rs] / (s64)CpuRegs[sop.rt];
		cpuHi = (s64)CpuRegs[sop.rs] % (s64)CpuRegs[sop.rt];
	}
}

void opDDIVU(void) {
	if (CpuRegs[sop.rt] == 0) {
		cpuLo = cpuHi = 0;
	} else {
		cpuLo = (u64)CpuRegs[sop.rs] / (u64)CpuRegs[sop.rt];
		cpuHi = (u64)CpuRegs[sop.rs] % (u64)CpuRegs[sop.rt];
	}
}

void opDIV(void) {
	if (CpuRegs[sop.rt] == 0) {
		cpuLo = cpuHi = 0;
	} else {
		cpuLo = ((s32)CpuRegs[sop.rs]) / ((s32)CpuRegs[sop.rt]);
		cpuHi = ((s32)CpuRegs[sop.rs]) % ((s32)CpuRegs[sop.rt]);
	}
}

void opDIVU(void) {
	if (CpuRegs[sop.rt] == 0) {
		cpuLo = cpuHi = 0;
	} else {
		cpuLo = ((u32)CpuRegs[sop.rs]) / ((u32)CpuRegs[sop.rt]);
		cpuHi = ((u32)CpuRegs[sop.rs]) % ((u32)CpuRegs[sop.rt]);
	}
}

#define MULT_X86(src1,src2) \
	__asm mov eax, [src1] \
	__asm mov edx, [src2] \
	__asm mul edx 

#define ADD_CARRY_X86(dest1,dest2) \
	__asm add dword ptr [dest1+4],eax \
	__asm adc dword ptr [dest2+4],edx

#define STORE_X86(dest) \
	__asm mov dword ptr [dest],eax \
	__asm mov dword ptr [dest+4],edx 

void opDMULT(void) {
	int neg_sign = 0;
	s64 v1 = CpuRegs[sop.rs];
	s64 v2 = CpuRegs[sop.rt];
	if (v1<0) { v1 = -v1; neg_sign = 1; }
	if (v2<0) { v2 = -v2; neg_sign = ! neg_sign; }
	u32 a = (u32)(v1>>32);
	u32 b = (u32)v1;
	u32 c = (u32)(v2>>32);
	u32 d = (u32)v2;
	MULT_X86(b,d)
	STORE_X86(cpuLo)
	MULT_X86(a,c)
	STORE_X86(cpuHi)
	MULT_X86(b,c)
	ADD_CARRY_X86(cpuLo,cpuHi)
	MULT_X86(a,d)
	ADD_CARRY_X86(cpuLo,cpuHi)

	if (neg_sign) { cpuLo = ~cpuLo; cpuHi = ~cpuHi; cpuLo +=1; if (cpuLo == 0) cpuHi+=1; }	
}

void opDMULTU(void) {
	u32 a = (u32)(CpuRegs[sop.rs]>>32);
	u32 b = (u32)CpuRegs[sop.rs];
	u32 c = (u32)(CpuRegs[sop.rt]>>32);
	u32 d = (u32)CpuRegs[sop.rt];
	MULT_X86(b,d)
	STORE_X86(cpuLo)
	MULT_X86(a,c)
	STORE_X86(cpuHi)
	MULT_X86(b,c)
	ADD_CARRY_X86(cpuLo,cpuHi)
	MULT_X86(a,d)
	ADD_CARRY_X86(cpuLo,cpuHi)
}

void opDSLL(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] << sop.sa;
}

void opDSLLV(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] << (CpuRegs[sop.rs] & 0x3f);
}

void opDSLL32(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] << (sop.sa+32);
}

void opDSRA(void) {
	CpuRegs[sop.rd] = ((s64)CpuRegs[sop.rt]) >> sop.sa;
}

void opDSRAV(void) {
	CpuRegs[sop.rd] = ((s64)CpuRegs[sop.rt]) >> (CpuRegs[sop.rs] & 0x3f);
}

void opDSRA32(void) {
	CpuRegs[sop.rd] = ((s64)CpuRegs[sop.rt]) >> (sop.sa+32);
}

void opDSRL(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] >> sop.sa;
}

void opDSRLV(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] >> (CpuRegs[sop.rs] & 0x3f);
}

void opDSRL32(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rt] >> (sop.sa+32);
}

void opDSUB(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rs] - CpuRegs[sop.rt];
}

void opDSUBU(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rs] - CpuRegs[sop.rt];
}

void opJ(void) {
	u32 target = (pc & 0xf0000000) + ((opcode << 2) & 0x0fffffff);
	u32 Jpc = pc;
	doInstr();
	pc = target;
#ifdef FAST_INFINITE_LOOP
	if (target==Jpc-4 && pr32(Jpc)==0) { 
		Jpc = pc;
		do {
			CheckInterrupts();//Kind of a way to speed up emulation.
		} while (Jpc==pc);
	}
#endif
}

void opJAL(void) {
	u32 target = (pc & 0xf0000000) + ((opcode << 2) & 0x0fffffff);
	CpuRegs[31] = pc+4;
	doInstr();
	pc = target;

}

void opJALR(void) {
	u32 target = CpuRegs[sop.rs];
	CpuRegs[sop.rd] = pc+4;
	doInstr();
	pc = target;
}

void opJR(void) {
	u32 target = CpuRegs[sop.rs];
	doInstr();
	pc = target;
}

void opLB(void) {
	CpuRegs[sop.rt] = (s8)(vr8(CpuRegs[sop.rs] + (s16)opcode));
}

void opLBU(void) {
	CpuRegs[sop.rt] = (u8)(vr8(CpuRegs[sop.rs] + (s16)opcode));
}

void opLD(void) {
	CpuRegs[sop.rt] = (vr64(CpuRegs[sop.rs] + (s16)opcode));
}

void opLDC1(void) {
	FpuRegs.l[sop.rt/2] = vr64(CpuRegs[sop.rs] + (s16)opcode);
}

void opLDC2(void) {
	CPU_ERROR("LDC2 Called",pc);
}

void opLDL(void) {
	CPU_ERROR("LDL Called",pc);
}

void opLDR(void) {
	CPU_ERROR("LDR Called",pc);
}

void opLH(void) {
	CpuRegs[sop.rt] = (s16)(vr16(CpuRegs[sop.rs] + (s16)opcode));
}

void opLHU(void) {
	CpuRegs[sop.rt] = (s64)(u16)(vr16(CpuRegs[sop.rs] + (s16)opcode));
}


void opLL(void) {
	CPU_ERROR("LL Called",pc);
}

void opLLD(void) {
	CPU_ERROR("LLD Called",pc);
}

void opLUI(void) {
	CpuRegs[sop.rt] = (s32)((u16)opcode << 16);
}

void opLW(void) {
	CpuRegs[sop.rt] = (s32)(vr32(CpuRegs[sop.rs] + (s16)opcode));
}

void opLWC1(void) {
	FpuRegs.w[sop.rt] = vr32(CpuRegs[sop.rs] + (s16)opcode);
}

void opLWC2(void) {
	CPU_ERROR("LWC2 Called",pc);
}

void opLWL(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u32 lwTmp = vr32(addr&0xfffffffc);
	switch (addr&3) {
	case 0: break;
	case 1: lwTmp  = (lwTmp << 8) | ((u32)CpuRegs[sop.rt]&0x000000ff); break;
	case 2: lwTmp  = (lwTmp << 16) | ((u32)CpuRegs[sop.rt]&0x0000ffff); break;
	default: lwTmp  = (lwTmp << 24) | ((u32)CpuRegs[sop.rt]&0x00ffffff); break;
	}
	CpuRegs[sop.rt] = (s32)lwTmp;
}

void opLWR(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u32 lwTmp = vr32(addr&0xfffffffc);
	switch (addr&3) {
	case 3: break;
	case 2: lwTmp  = (lwTmp >>8) | ((u32)CpuRegs[sop.rt]&0xff000000); break;
	case 1: lwTmp  = (lwTmp >> 16) | ((u32)CpuRegs[sop.rt]&0xffff0000); break;
	default: lwTmp  = (lwTmp >> 24) | ((u32)CpuRegs[sop.rt]&0xffffff00); break;
	}
	CpuRegs[sop.rt] = (s32)lwTmp;
}

void opLWU(void) {
	CpuRegs[sop.rt] = (u32)(vr32(CpuRegs[sop.rs] + (s16)opcode));//unrisky
}

void opMFHI(void) {
	CpuRegs[sop.rd] = cpuHi;
}

void opMFLO(void) {
	CpuRegs[sop.rd] = cpuLo;
}

void opMTHI(void) {
	cpuHi = CpuRegs[sop.rt];
}

void opMTLO(void) {
	cpuLo = CpuRegs[sop.rt];
}

void opMULT(void) {
	s64 temp = Int32x32To64((u32)CpuRegs[sop.rs],(u32)CpuRegs[sop.rt]);
	cpuHi = (s32)(temp >> 32);
	cpuLo = (s32)temp;
}

void opMULTU(void) {
	cpuLo = UInt32x32To64((u32)CpuRegs[sop.rs],(u32)CpuRegs[sop.rt]);
	cpuHi = (s32)(cpuLo >> 32);
	cpuLo = (s32)cpuLo;
}

void opNOR(void) {
	CpuRegs[sop.rd] = ~(CpuRegs[sop.rs] | CpuRegs[sop.rt]);
}

void opOR(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rs] | CpuRegs[sop.rt];
}

void opORI(void) {
	CpuRegs[sop.rt] = CpuRegs[sop.rs] | ((u16)opcode);
}

void opSB(void) {
	vw8(CpuRegs[sop.rs] + (s16)opcode,(u8)CpuRegs[sop.rt]);
}

void opSC(void) {
	CPU_ERROR("SC Called",pc);
}

void opSCD(void) {
	CPU_ERROR("SCD Called",pc);
}

void opSD(void) {
	vw64(CpuRegs[sop.rs] + (s16)opcode,CpuRegs[sop.rt]);
}

void opSDC1(void) {
	vw64(CpuRegs[sop.rs] + (s16)opcode,FpuRegs.l[sop.rt/2]);
}

void opSDC2(void) {
	CPU_ERROR("SDC2 Called",pc);
}

void opSDL(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u64 lwTmp = vr64(addr&0xfffffff8);
	switch (addr&7) {
	case 0: lwTmp = CpuRegs[sop.rt]; break;
	case 1: lwTmp  = ((u64)CpuRegs[sop.rt] >> 8) | (lwTmp&0xff00000000000000); break;
	case 2: lwTmp  = ((u64)CpuRegs[sop.rt] >> 16) | (lwTmp&0xffff000000000000); break;
	case 3: lwTmp  = ((u64)CpuRegs[sop.rt] >> 24) | (lwTmp&0xffffff0000000000); break;
	case 4: lwTmp  = ((u64)CpuRegs[sop.rt] >> 32) | (lwTmp&0xffffffff00000000); break;
	case 5: lwTmp  = ((u64)CpuRegs[sop.rt] >> 40) | (lwTmp&0xffffffffff000000); break;
	case 6: lwTmp  = ((u64)CpuRegs[sop.rt] >> 48) | (lwTmp&0xffffffffffff0000); break;
	default: lwTmp  = ((u64)CpuRegs[sop.rt] >> 56) | (lwTmp&0xffffffffffffff00); break;
	}
	vw64(addr&0xfffffff8,lwTmp);
}

void opSDR(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u64 lwTmp = vr64(addr&0xfffffffc);
	switch (addr&3) {
	case 7: lwTmp = CpuRegs[sop.rt]; break;
	case 6: lwTmp  = ((u64)CpuRegs[sop.rt] << 8) | (lwTmp&0x00000000000000ff); break;
	case 5: lwTmp  = ((u64)CpuRegs[sop.rt] << 16) | (lwTmp&0x000000000000ffff); break;
	case 4: lwTmp  = ((u64)CpuRegs[sop.rt] << 24) | (lwTmp&0x0000000000ffffff); break;
	case 3: lwTmp  = ((u64)CpuRegs[sop.rt] << 32) | (lwTmp&0x00000000ffffffff); break;
	case 2: lwTmp  = ((u64)CpuRegs[sop.rt] << 40) | (lwTmp&0x000000ffffffffff); break;
	case 1: lwTmp  = ((u64)CpuRegs[sop.rt] << 48) | (lwTmp&0x0000ffffffffffff); break;
	default: lwTmp  = ((u64)CpuRegs[sop.rt] << 56) | (lwTmp&0x00ffffffffffffff); break;
	}
	vw64(addr&0xfffffffc,lwTmp);
}

void opSH(void) {
	vw16(CpuRegs[sop.rs] + (s16)opcode,(u16)CpuRegs[sop.rt]);
}

void opSLL(void) {
	if (opcode==0) return;
	CpuRegs[sop.rd] = (s32)(CpuRegs[sop.rt] << sop.sa);
}

void opSLLV(void) {
	CpuRegs[sop.rd] = (s32)(CpuRegs[sop.rt] << (CpuRegs[sop.rs] & 0x1f));
}

void opSLT(void) {
	if (((s64)CpuRegs[sop.rs]) < ((s64)CpuRegs[sop.rt])) {
		CpuRegs[sop.rd] = 1;
	} else {
		CpuRegs[sop.rd] = 0;
	}
}

void opSLTI(void) {
	s64 test = (s16)opcode;
	if (((s64)CpuRegs[sop.rs]) < test) {
		CpuRegs[sop.rt] = 1;
	} else {
		CpuRegs[sop.rt] = 0;
	}
}

void opSLTIU(void) {
	u64 test = ((s16)opcode);
	if (CpuRegs[sop.rs] < test) {
		CpuRegs[sop.rt] = 1;
	} else {
		CpuRegs[sop.rt] = 0;
	}
}

void opSLTU(void) {
	if (CpuRegs[sop.rs] < CpuRegs[sop.rt]) {
		CpuRegs[sop.rd] = 1;
	} else {
		CpuRegs[sop.rd] = 0;
	}
}

void opSRA(void) {
	CpuRegs[sop.rd] = (s32)(((s32)CpuRegs[sop.rt]) >> sop.sa);
}

void opSRAV(void) {
	CpuRegs[sop.rd] = (s32)(((s32)CpuRegs[sop.rt]) >> (CpuRegs[sop.rs] & 0x1f));
}

void opSRL(void) {
	CpuRegs[sop.rd] = (s32)(((u32)CpuRegs[sop.rt]) >> sop.sa);
}

void opSRLV(void) {
	CpuRegs[sop.rd] = (s32)(((u32)CpuRegs[sop.rt]) >> (CpuRegs[sop.rs] & 0x1f));
}

void opSUB(void) {
	CpuRegs[sop.rd] = (s32)(CpuRegs[sop.rs] - CpuRegs[sop.rt]);
}

void opSUBU(void) {
	CpuRegs[sop.rd] = (s32)(((s32)CpuRegs[sop.rs]) - ((s32)CpuRegs[sop.rt]));
}

void opSW(void) {
	vw32(CpuRegs[sop.rs] + (s16)opcode,(u32)CpuRegs[sop.rt]);
}

void opSWC1(void) {
	vw32(CpuRegs[sop.rs] + (s16)opcode,FpuRegs.w[sop.rt]);
}

void opSWC2(void) {
	CPU_ERROR("SWC2 Called",pc);
}

void opSWL(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u32 lwTmp = vr32(addr&0xfffffffc);
	switch (addr&3) {
	case 0: lwTmp = CpuRegs[sop.rt]; break;
	case 1: lwTmp  = ((u32)CpuRegs[sop.rt] >> 8) | (lwTmp&0xff000000); break;
	case 2: lwTmp  = ((u32)CpuRegs[sop.rt] >> 16) | (lwTmp&0xffff0000); break;
	default: lwTmp  = ((u32)CpuRegs[sop.rt] >> 24) | (lwTmp&0xffffff00); break;
	}
	vw32(addr&0xfffffffc,lwTmp);

}

void opSWR(void) {
	u32 addr = CpuRegs[sop.rs] + (s16)opcode;
	u32 lwTmp = vr32(addr&0xfffffffc);
	switch (addr&3) {
	case 3: lwTmp = CpuRegs[sop.rt]; break;
	case 2: lwTmp  = ((u32)CpuRegs[sop.rt] << 8) | (lwTmp&0x000000ff); break;
	case 1: lwTmp  = ((u32)CpuRegs[sop.rt] << 16) | (lwTmp&0x0000ffff); break;
	default: lwTmp  = ((u32)CpuRegs[sop.rt] << 24) | (lwTmp&0x00ffffff); break;
	}
	vw32(addr&0xfffffffc,lwTmp);
}

void opSYNC(void) {
}

void opSYSCALL(void) {
	CPU_ERROR("Syscall Called",pc);
}

void opTEQ(void){
	CPU_ERROR("TEQ Called",pc);
}

void opTEQI(void){
	CPU_ERROR("TEQI Called",pc);
}

void opTGE(void) {
	CPU_ERROR("TGE Called",pc);
}

void opTGEI(void){
	CPU_ERROR("TGEI Called",pc);
}

void opTGEIU(void){
	CPU_ERROR("TGEIU Called",pc);
}

void opTGEU(void) {
	CPU_ERROR("TGEU Called",pc);
}

void opTLT(void){
	CPU_ERROR("TLT Called",pc);
}

void opTLTI(void) {
	CPU_ERROR("TLTI Called",pc);
}

void opTLTIU(void) {
	CPU_ERROR("TLTIU Called",pc);
}

void opTLTU(void) {
	CPU_ERROR("TLTU Called",pc);
}

void opTNE(void) {
	CPU_ERROR("TNE Called",pc);
}

void opTNEI(void) {
	CPU_ERROR("TNEI Called",pc);
}

void opXOR(void) {
	CpuRegs[sop.rd] = CpuRegs[sop.rs] ^ CpuRegs[sop.rt];
}

void opXORI(void) {
	CpuRegs[sop.rt] = CpuRegs[sop.rs] ^ ((u16)opcode);
}

void opCOP1(void);

void (*r4300i[0x40])() = {
    opSPECIAL,	opREGIMM,	opJ,	opJAL,		opBEQ,	opBNE,	opBLEZ,	opBGTZ,  
    opADDI,		opADDIU,	opSLTI,	opSLTIU,	opANDI,	opORI,	opXORI,	opLUI,
    opCOP0,		opCOP1,		opCOP2,	opNI,		opBEQL,	opBNEL,	opBLEZL,opBGTZL,  
    opDADDI,	opDADDIU,	opLDL,	opLDR,		opNI,	opNI,	opNI,	opNI,  
    opLB,		opLH,		opLWL,	opLW,		opLBU,	opLHU,	opLWR,	opLWU,  
    opSB,		opSH,		opSWL,	opSW,		opSDL,	opSDR,	opSWR,	opCACHE,
    opLL,		opLWC1,		opLWC2,	opNI,		opLLD,	opLDC1, opLDC2,	opLD, 
    opSC,		opSWC1,		opSWC2,	opNI,		opSCD,	opSDC1, opSDC2,	opSD 
};

void (*special[0x40])() = {
    opSLL,	opNI,		opSRL,	opSRA,	opSLLV,		opNI,		opSRLV,		opSRAV,  
    opJR,	opJALR,		opNI,	opNI,	opSYSCALL,	opBREAK,	opNI,		opSYNC,  
    opMFHI,	opMTHI,		opMFLO,	opMTLO,	opDSLLV,	opNI,		opDSRLV,	opDSRAV,  
    opMULT,	opMULTU,	opDIV,	opDIVU,	opDMULT,	opDMULTU,	opDDIV,		opDDIVU,
    opADD,	opADDU,		opSUB,	opSUBU,	opAND,		opOR,		opXOR,		opNOR,  
    opNI,	opNI,		opSLT,	opSLTU,	opDADD,		opDADDU,	opDSUB,		opDSUBU,  
    opTGE,	opTGEU,		opTLT,	opTLTU,	opTEQ,		opNI,		opTNE,		opNI,  
    opDSLL,	opNI,		opDSRL,	opDSRA,	opDSLL32,	opNI,		opDSRL32,	opDSRA32  
};

void (*regimm[0x20])() = {
    opBLTZ,		opBGEZ,		opBLTZL,	opBGEZL,	opNI,	opNI,	opNI,	opNI,
    opTGEI,		opTGEIU,	opTLTI,		opTLTIU,	opTEQI,	opNI,	opTNEI,	opNI,
    opBLTZAL,	opBGEZAL,	opBLTZALL,	opBGEZALL,	opNI,	opNI,	opNI,	opNI,
    opNI,		opNI,		opNI,		opNI,		opNI,	opNI,	opNI,	opNI,
};

