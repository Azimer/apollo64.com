           *********************************
           ******  The Apollo Project ******
           ******        v0.01a       ******
           ******      05-19-2000     ******
           *********************************



DISCLAIMER and LEGAL STUFF: (Please read before running the software!!!)
---------------------------
 Apollo is freeware - NEVER SELL Apollo or any portion of the software!
   We will take any legal action necessary to protect our rights.

 Anything you do with Apollo, or any portion of the software, is your
   responsibility.  We can not be held accountable for any damages Apollo
   does to you or anything else by your use of this software.  If you do
   not agree, delete this software NOW. (IOW don't blame us for killing
   dad's computer for christ sakes)

 NEVER, EVER.... (like Chris Jericho says it) EVER distribute Apollo with
   commercial ROMs!!!!  It's illegal!  I didn't write this software for some
   one to distribute commercial ROMs with it.  In fact, don't distribute
   Apollo in a modified archive.  Apollo should contain ALL files as they
   were when distributed with the release of the EXE.

 The rights of all trademarks mentioned in this document and in the emulator
   binary executable, Apollo, are retained by their respective owners.

 We have NO affiliated with rightful owner of trademarks, copyrights, patents,
   or otherwise of emulated hardware, nor of software that functions in the
   emulation.

 Please no rom begging.  You emails will be sent immediately to our legal team
   for possible charges of harassment.  You have been warned!


INTRODUCTION:
-------------
   This is just going to be a brief introduction to give you a little background
 on this project.  The Apollo Project really started way back in September when
 4 friends got together to make an N64 emulator.  We were doing very well until
 differences got between us, and we are now down to 2 members.  After wondering
 what to do with the project, Phrodide decided to create something new without
 using any of the former coder's code.  What you see here is the result of that
 effort and a month of time stress.  We are still alive and the next release
 will be a lot better.
    -Azimer (5/19/00)

SYSTEM REQUIREMENTS:
--------------------
 Unknown Really...  Since we are using an interpretive core, you will need
 the fastest machine on the market to get even close to the right speed.  Even
 that isn't close enough. ;)

USAGE:
------
 Configure Keyboard from Controllers Option.  Load up Demo ROM.  Look at Demo.
 Wonder when we will get a recompiler and HLE going :)

WHAT'S NEXT:
------------
 Everything... We need to rewrite a lot of stuff.


WHAT'S NEW/HISTORY:
-------------------
 - May 19th, 2000 - Initial Version... everything is new :)


THANK YOUs and COMMENTS:
------------------------
  If you find bugs in this emulator (besides games not working or demos not
  working), then feel free to contact us at our website:
    http://apollo.emulation64.com/
  If there isn't a feature in here that you would like please use the forum.
  If you want a better readme, give me a suggestion... I can't read minds.
  Now... I would like to thank the follow people for info and help or whatnot:
    Zilmar, LaC, CricketNE, Mike Tedder, Niki Waibel, Marius Dumitrean, Daniel
    Lehman, Atreides, hWnd, _Demo_, schibo, icepir8, gerrit, Martin64,
    #emulation64, and everyone else I neglected to mention :(.
  Greets go out to:
    All the people in #n64dev, #nesdev, and #snesdev.
  Now for the most important person to the project:
    -=HUGE=- UBERL33T THX to Jabo.  Truly if it wasn't for him APOLLO 
    would have never existed.

-Eclipse Can Not Die
 ReadMe By: Azimer
 Coding By: Phrodide and Azimer
 Apollo Icon By: Jabo (it looks cool man!)
