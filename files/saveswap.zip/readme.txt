Ok...  I spent a VERY small time on this program so bare with me...

Purpose:

This program will convert SRAM and FlashRAM files from one format to another.

Use:

1. Run this program.
2. Select a file to be converted.
3. Type in the name of the file for destination.
4. If a success dialog box comes up ok then it's all good.

Warnings:

*** BACK UP YOU GAME BEFORE CONVERTING!!! ****
You can do this easily by right clicking on the rom and clicking copy.
Then click somewhere other then the save game and click paste.  It's now backed up.

This will convert the games from the following formats:

N64 Endianess		Reversed Endianess
------------------------------------------------------------
Copy Device Dumps	TR64
Apollo			PJ64
NEMU
Daedalus???

*** NOTICE ****
The programs in the columns are compatible!  Just rename them. (NEMU's Zelda OOT SRAM is compatible with Apollo's)
You MUST use this utility to convert the save games for use in the other column.

ex. Apollo->PJ64
    NEMU->TR64
    N64 Endianess->Reversed Endianess
    TR64->NEMU

-Azimer