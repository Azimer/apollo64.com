Audio Plugin Readme
-------------------

Please notice:
  This plugin was designed to run on TR64.  Any use of this plugin on any other emulator
may have undesired results.  Use at your own risk.


What's New:
-----------

- v0.12b - I decided to include this small readme.txt for all maintenance releases.
	 - Added some code to help prevent the plugin from erroring out when a rom is closed.
	 - Made the AiHack enabled by default (It's preferred in most situations)
	 - Added some safeguards to prevent areas of code from clashing (due to threading).



Thanks,

-Azimer