Last Updated: 9:04 PM 5/12/2001

Audio Plugin Readme
-------------------

Please notice:
  This plugin was designed to run on TR64.  Any use of this plugin on any other emulator
may have undesired results.  Use at your own risk.


What's New:
-----------
- v0.13  - Fixed the issue in MKT, Robotron, Cruisin USA, Rampage World Tour, and some others.
    "  b - Fixed a problem with the Interleave... - Thanks to LaC for clarifying
	 - Fixed bad VADPCM decompression with the 4:1 compression ratio. Skull Kid is fine :)
	 - Halved the size of the DLL file...  cut out all the garbage.
	 - Went back to standard C calling convention.  Fastcall caused too many issues...

- v0.12b - I decided to include this small readme.txt for all maintenance releases.
	 - Added some code to help prevent the plugin from erroring out when a rom is closed.
	 - Made the AiHack enabled by default (It's preferred in most situations)
	 - Added some safeguards to prevent areas of code from clashing (due to threading).

Known Issues:
-------------
1. Problem: Zelda MM "People Bug" - Skullkid and other people in the rom sound funny.
   Solution: Been Fixed - 4:1 Ratio sample decompression error

2. Mario64's Intro...
   Solution: Been Fixed - Interleave

3. Problem: Paper Mario has a lot of static...
   Solution: None

4. Problem: Slight static in the Zelda MM town music
   solution: None

5. Problem: Buzzing in Banjo Kazooie
   Solution: None

6. Problem: Buzzing in the high note in Zelda MM as a deku boy
   Solution: None

7. Problem: Audio all around sounds off.
   Solution: This is because of the Envelope Mixer.  I need to write a better one.

8. Problem: Zelda MM some off music in that one shop in the town where the two love birds are in the 
            shop or is it a game?
   Solution: I don't even know about this bug.

Future:
-------
- Add MusyX
- Add MP3 Audio to ABI3
- Fix the known issues
- Fix the EnvMixer in ABI1 and ABI3
- Add Game Sync to Audio Buffers
- Add Audio Filters


Thanks,

-Azimer